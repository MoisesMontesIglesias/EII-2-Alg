#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      uo296102
#
# Created:     09/04/2024
# Copyright:   (c) uo296102 2024
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def leerFichero(fich):
    matriz = []
    resultadoFila = []
    resultadoColumna =[]
    fi=open(fich,"r")
    for linea in fi:
        lista = linea.strip().split(" ")
        if(len(lista) == 1):
            tamaño = int(lista[0])
        else:
            fila = []
            for i in range(len(lista)):
                if(lista[i] == "="):
                    resultadoFila.append(lista[i+1])
                    break
                elif(len(resultadoFila) > 0):
                    if(resultadoFila[len(resultadoFila) -1] == "="):
                        resultadoColumna.append(lista[i])
                    else:
                        fila.append(lista[i])
                else:
                    fila.append(lista[i])
            if(len(fila) > 0):
                matriz.append(fila)

    fi.close()
    resultadoFila.pop()
    cadena = ValorPorDefecto(matriz)
    return tamaño, matriz, resultadoFila, resultadoColumna, cadena

def ValorPorDefecto(matriz):
    valor = []
    for i in range(0,len(matriz),2):
        for j in range(0,len(matriz[i]),2):
            if(matriz[i][j] != '?'):
                valor.append(matriz[i][j])
            else:
                valor.append('0')

    return valor

##def SepararLista(valor, numero):
##    x = str(valor)
##    y = ""
##    while(len(x) + len(y) < len(numero)):
##        y+="0"
##
##    return y+x

def NumeroPosible(numeroGenerado, matriz, numeroPorDefecto, valor, tamaño):
    if(valor > len(matriz[0])-1):
        return True
    else:
        for i in range(tamaño):
            if(numeroPorDefecto[i] != "0" and int(numeroGenerado[i]) != int(numeroPorDefecto[i])):
                return False
        NumeroPosible(numeroGenerado, matriz, numeroPorDefecto, valor+2)

def BackTracking(numeroGenerado, tamaño, matriz, numeroPorDefecto, resultadoFila, resultadoColumna):
    if(EsSolucion(numeroGenerado, matriz, 0) == True):
        printMatriz()
        SolucionEncontrada = True
    else:
        SolucionEncontrada = False
        while(numeroGenerado < NumerosAGenerar and SolucionEncontrada != False):
            numeroGenerado+=1
            if(NumeroPosible(list(numeroGenerado), matriz, numeroPorDefecto, 0, tamaño) == True):
                BackTracking(numeroGenerado)

def EsSolucion(numeroGenerado, matriz, valor, tamaño):
    if(valor > len(matriz[0])-1):
        return True
    else:
        for i in range(int(len(matriz[0])/2+1)):
            estadoFila = SaberSiFilaValida(tamaño, list(numeroGenerado), i, matriz, resultadoFila)
            estadoColumna = SaberSiColumnaValida(tamaño, list(numeroGenerado), i, matriz, resultadoColumna)
            if(estadoFila == False or estadoColumna == False):
                return False
            else:
                EsSolucion(numeroGenerado, matriz, valor+2, tamaño)

def GenerarNumeroValido(numero):
    if

def main():
    tamaño, matriz, resultadoFila, resultadoColumna, numeroPorDefecto = leerFichero('test01.txt')
    BackTracking(GenerarNumeroValido(0), tamaño, matriz, resultadoFila, resultadoColumna, numeroPorDefecto)



def SaberSiColumnaValida(tamaño, numeroGenerado, columna, matriz, posicionNumero):
    posicion = columna
    numero = int(numeroGenerado[posicion])
    for i in range(1,matriz[columna],2):
        posicion += tamaño
        if(matriz[fila][i] == "+"):
            numero += int(numeroGenerado[posicion])
        elif(matriz[fila][i] == "-"):
            numero -= int(numeroGenerado[posicion])
        elif(matriz[fila][i] == "*"):
            numero *= int(numeroGenerado[posicion])
        else:
            if(numero == 0 or int(numeroGenerado[posicion] == 0)):
                numero = 0
            else:
                numero /= int(numeroGenerado[posicion])
    if (numero == resultadoFila[i]):
        return True
    else:
        return False

def SaberSiFilaValida(tamaño, numeroGenerado, fila, matriz, posicionNumero):
    posicion = fila*tamaño
    numero = int(numeroGenerado[posicion])
    for i in range(1,matriz[fila],2):
        posicion += 1
        if(matriz[fila][i] == "+"):
            numero += int(numeroGenerado[posicion])
        elif(matriz[fila][i] == "-"):
            numero -= int(numeroGenerado[posicion])
        elif(matriz[fila][i] == "*"):
            numero *= int(numeroGenerado[posicion])
        else:
            if(numero == 0 or int(numeroGenerado[posicion] == 0)):
                numero = 0
            else:
                numero /= int(numeroGenerado[posicion])
    if (numero == resultadoFila[i]):
        return True
    else:
        return False

def printMatriz(tamaño, matriz, resultadoFila, resultadoColumna, valor, numero):
    ListaNumero = list(numero)
    for i in range(len(matriz)):
        for j in range(len(matriz[i])):
            if(matriz[i][j] in ("0123456789?")):
                matriz[i][j] = ListaNumero[0]
                ListaNumero.pop(0)
    for i in range(len(matriz)):
        if(i%2 == 0):
            cadena = matriz[i][0] + "\t"
            for j in range(1,len(matriz[i])):
                if(j == len(matriz[i])-1):
                    cadena += matriz[i][j] + "\t = \t" + resultadoFila[int(i/2)]
                else:
                    cadena += matriz[i][j] + "\t"
            print(cadena)
        else:
            cadena2 = ""
            for k in range(len(matriz[i])):
                if(k == len(matriz[i]) - 1):
                    cadena2 += matriz[i][k]
                else:
                    cadena2 += matriz[i][k] + "\t\t"
            print(cadena2)

    cadena = ""
    for i in range(int(len(matriz[i])/2)+1):
        if(len(matriz)-1 == i):
            cadena += "="
        else:
            cadena += "=\t\t"
    print(cadena)
    cadena = ""
    for i in range(len(resultadoColumna)):
        if(i == len(resultadoColumna) - 1):
            cadena += resultadoColumna[i]
        else:
            cadena += resultadoColumna[i] + "\t\t"
    print(cadena)

main()
